import React from "react";
import { Link } from "react-router-dom";
function Nav() {
  return (
    <div>
      <Link to="/">Exercise</Link> ||
      <Link to="/Tuiter">Tuiter</Link> ||
      <Link to="/HelloWorld">HelloWorld</Link> ||
      <Link to="/e6">Exercise6</Link> ||
      <Link to="/ex6">Ex6</Link>
    </div>
  );
}

export default Nav;
