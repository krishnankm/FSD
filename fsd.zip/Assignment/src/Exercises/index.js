import Exercise5 from "./e5";
import Nav from "../nav";
import { Routes, Route } from "react-router";
function Exercises() {
  return (
    <div>
      <Nav />
      <Routes>
        {/* <Route index element={<Exercise6 />} /> */}
        {/* <Route path="e6" element={<Exercise5 />} />
        <Route path="ex6" element={<Exercises6 />} /> */}
      </Routes>
    </div>
  );
}
export default Exercises;
