const Component = () => {
  return (
    <>
      <h1>Hello this is the new comp</h1>
      <div className="row" style={{ backgroundColor: "red" }}>
        <h1>dfindf</h1>
      </div>
    </>
  );
};
export default Component;
