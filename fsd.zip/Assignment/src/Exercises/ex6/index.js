import React from "react";

const Exercises6 = () => {
  return (
    <>
      <h1>Exercise 6</h1>
    </>
  );
};

export default Exercises6;
