import { createSlice } from "@reduxjs/toolkit";

const initialTodos = [
  {
    _id: "123",
    do: "Walk",
    done: "false",
  },
  {
    _id: "143",
    do: "Talk",
    done: "true",
  },
];

const todoSlice = createSlice({
  name: "todos",
  initialState: initialTodos,
  reducers: {
    addTodo(state, action) {
      state.push({
        _id: new Date().getTime(),
        do: action.payload.do,
        done: false,
      });
    },
    deleteTodo(state, action) {
      const index = action.payload;
      state.splice(index, 1);
    },
    todoDoneToggle(state, action) {
      const todo = state.find((todo) => todo._id === action.payload._id);
      todo.done = !todo.done;
    },
  },
});
export const { addTodo, deleteTodo, todoDoneToggle } = todoSlice.actions;
export default todoSlice.reducer;
