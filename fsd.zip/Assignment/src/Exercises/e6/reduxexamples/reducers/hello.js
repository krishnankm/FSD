const hello = () => {
  return { message: "helloooo" };
};
export default hello;
