import React from "react";

const cond = () => {
  const loggedIn = true;
  if (loggedIn) {
    return <h1>Welcome </h1>;
  } else {
    return <h1>Log In</h1>;
  }
};
export default cond;
