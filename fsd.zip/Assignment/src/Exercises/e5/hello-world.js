import Nav from "../../nav";
function HelloWorld() {
  return (
    <div>
      <Nav />
      <h1>Hello Qorld</h1>
    </div>
  );
}
export default HelloWorld;
