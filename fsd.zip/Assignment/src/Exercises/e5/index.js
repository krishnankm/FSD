import Classes from "./classes";
import Styles from "./styles";

function Exercise5() {
  return (
    <div>
      <h1>Exercise 5</h1>
      <Classes />
      {/* <Styles /> */}
      <cond />
    </div>
  );
}
export default Exercise5;
