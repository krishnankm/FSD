import Exercises from "./Exercises";
import HelloWorld from "./Exercises/e5/hello-world";
import Exercise6 from "./Exercises/e6/";
import Tuiter from "./Tuiter";

import { BrowserRouter } from "react-router-dom";
import { Routes, Route } from "react-router-dom";
function App() {
  return (
    <BrowserRouter>
      <div className="container">
        <Routes>
          {/* <Route index element={<Exercises />} /> */}
          <Route path="/HelloWorld" element={<HelloWorld />} />
          <Route path="/*" element={<Tuiter />} />
          <Route path="/e6" element={<Exercise6 />} />
        </Routes>
      </div>
    </BrowserRouter>
    // <div>
    //   <Tuiter />
    // </div>
  );
}
export default App;
