import React from "react";
// import postsArray from "./TuitStats.json";
import { useSelector } from "react-redux";
import Homeitem from "./TuitItem";
import WhatsHappening from "./whats-happening";
const HomeComponent = () => {
  const postsArray = useSelector((state) => state.hometuits);
  return (
    <div className="row ">
      <WhatsHappening />
      <div className="col-10 position-relative">
        <ul className="list-group">
          {postsArray.map((post) => (
            <Homeitem post={post} />
          ))}
        </ul>
      </div>
    </div>
  );
};
export default HomeComponent;
