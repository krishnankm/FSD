import React from "react";
// import { faRegular, faHeart } from "@fortawesome/pro-solid-svg-icons";
import { useDispatch } from "react-redux";
import { deleteTuit, liker } from "../reducers/home-reducer";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faHeart,
  faArrowUpFromBracket,
  faRetweet,
  faComment,
  faEllipsis,
  faCircleCheck,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import { faHeart as regularHeart } from "@fortawesome/free-regular-svg-icons";

// import { icon } from "@fortawesome/fontawesome-svg-core/import.macro";
const Homeitem = ({
  post = {
    hasimage: true,
    account: "Space",
    dp: "tesla.png",
    handle: "@SpaceX",
    time: "23h",
    tuit: "Tesla Cybertruck lands on Mars and picks up the Curiosity rover on its 6' bed",
    image: "tesla.png",
    like: "23k",
    replies: "2k",
    retweet: "23k",
  },
}) => {
  let dp = 1;
  if ("retweeted" in post) {
    dp = 33;
  } else {
    dp = 7;
  }

  const dispatch = useDispatch();
  const deleteTuitHandler = (id) => {
    dispatch(deleteTuit(id));
  };
  const likehandler = (id) => {
    dispatch(liker(id));
  };
  return (
    <li className="col-11 list-group-item" style={{ width: "120%" }}>
      <div className="row " style={{ width: "100%" }}>
        {"retweeted" in post && (
          <>
            <div style={{ marginLeft: "20px", marginBottom: "3px" }}>
              <FontAwesomeIcon
                icon={faRetweet}
                style={{ marginRight: "5px" }}
              />{" "}
              {post.retweeter} Retweeted
            </div>
          </>
        )}
        <div className="ms-5">
          <div style={{ display: "flex" }}>
            <div>
              <b>{post.account}</b>
              <FontAwesomeIcon
                icon={faCircleCheck}
                style={{ marginLeft: "5px" }}
              />{" "}
              {post.handle} . {post.time}
            </div>
            <FontAwesomeIcon
              icon={faEllipsis}
              style={{ position: "absolute", right: "40px" }}
            />
            <FontAwesomeIcon
              icon={faXmark}
              style={{ position: "absolute", right: "60px" }}
              onClick={() => deleteTuitHandler(post._id)}
            />
          </div>
          <div style={{ marginBottom: "15px", paddingRight: "25px" }}>
            {post.tuit}
          </div>
        </div>
        <>
          {"image" in post && (
            <img
              src={`/images/${post.image}`}
              alt="Not Found"
              style={{ width: "90%", marginLeft: "50px" }}
            />
          )}
        </>
        {
          <>
            {"intweet" in post && (
              <div style={{ width: "80%", marginLeft: "50px" }}>
                <Homeitem post={post.intweet} />
              </div>
            )}
            {"like" in post && (
              <div
                className="ms-5 mt-2"
                style={{
                  display: "flex",
                  width: "80%",
                  justifyContent: "space-between",
                }}
              >
                <div>
                  <FontAwesomeIcon
                    icon={faComment}
                    style={{ marginRight: "5px" }}
                  />{" "}
                  {post.replies}
                </div>
                <div>
                  <FontAwesomeIcon
                    icon={faRetweet}
                    style={{ marginRight: "5px" }}
                  />
                  {post.retweet}
                </div>
                <div>
                  <FontAwesomeIcon
                    icon={post.liked ? faHeart : regularHeart}
                    // icon={regular("heart")}
                    // icon="fa-regular fa-heart"
                    style={{
                      color: `${post.liked ? "red" : "black"}`,
                      marginRight: "5px",
                    }}
                    onClick={() => likehandler(post._id)}
                  />
                  {post.like}
                </div>
                <div>
                  <FontAwesomeIcon icon={faArrowUpFromBracket} />
                </div>
              </div>
            )}
          </>
        }
        {
          <>
            {post.thread && (
              <a
                href="thread.html"
                style={{
                  textDecoration: "none",
                  marginLeft: "50px",
                  marginTop: "10px",
                }}
              >
                Show This thread
              </a>
            )}
          </>
        }
        <img
          src={`/images/${post.dp}`}
          style={{
            color: "red",
            height: "40px",
            top: `${dp}px`,
            width: "65px",
            borderRadius: "50%",
            margin: "0",
            position: "absolute",
          }}
          alt="Not found"
          className="me-2"
        />
      </div>
    </li>
  );
};

export default Homeitem;
