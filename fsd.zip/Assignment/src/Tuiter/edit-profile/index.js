import { faArrowLeft, faXmark } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { updateinfos } from "../reducers/profile-reducer";
import { useDispatch } from "react-redux";
const EditProfileComponent = () => {
  const user = useSelector((state) => state.profile);
  let [name, setname] = useState("");
  let [location, setlocation] = useState("");
  let [bio, setbio] = useState("");

  const dispatch = useDispatch();
  const updater = (name, location, bio) => {
    dispatch(updateinfos(name, location, bio));
  };

  return (
    <div className="row">
      <div className="d-flex text-start">
        <div className="mb-2 ">
          <Link to="/profile">
            <FontAwesomeIcon
              icon={faXmark}
              height={40}
              style={{ color: "blue" }}
            />{" "}
          </Link>
        </div>
        <div
          className="ms-4 d-inline-flex"
          style={{
            justifyContent: "space-between",
            width: "89%",
          }}
        >
          <div>
            <b>Edit Profile</b>
          </div>
          <div>
            <Link
              to="/profile"
              className="btn btn-primary"
              onClick={() => updater([name, bio, location])}
            >
              Save
            </Link>
          </div>
        </div>{" "}
      </div>
      <div style={{ marginBottom: "120px" }}>
        <img
          src={`/images/${user.bannerPicture}`}
          className="mt-2"
          style={{ height: "200px" }}
        />
        <img
          src={`/images/${user.profilePicture}`}
          className="position-absolute"
          style={{
            borderWidth: "5px",
            borderRadius: "50%",
            borderColor: "white",
            left: "20px",
            top: "200px",
            height: "150px",
            borderStyle: "solid",
          }}
        />
      </div>{" "}
      <div>
        <p>Name</p>
        <textarea
          value={name}
          placeholder={user.name}
          defaultValue={user.name}
          className="form-control border-0"
          onChange={(event) => setname(event.target.value)}
        ></textarea>
        <p>Bio</p>
        <textarea
          value={bio}
          placeholder={user.bio}
          defaultValue={user.bio}
          className="form-control border-0"
          onChange={(event) => setbio(event.target.value)}
        >
          {user.bio}
        </textarea>
        <p>Location</p>
        <textarea
          value={location}
          placeholder="Location"
          className="form-control border-0"
          onChange={(event) => setlocation(event.target.value)}
        ></textarea>
      </div>
    </div>
  );
};

export default EditProfileComponent;
