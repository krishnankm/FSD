import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faLocationDot } from "@fortawesome/free-solid-svg-icons";
import { faCalendar } from "@fortawesome/free-regular-svg-icons";

import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const ProfileComponent = () => {
  const user = useSelector((state) => state.profile);
  console.log(user);

  return (
    <div className="row">
      <div className="position-relative">
        <div className="d-flex text-start">
          <div className="pt-2">
            <FontAwesomeIcon
              icon={faArrowLeft}
              className="me-2"
              height={40}
              style={{ color: "blue" }}
            />{" "}
          </div>
          <div className="ms-4">
            <b>{user.name}</b> <br /> 0 Tweets
          </div>{" "}
        </div>
        <div style={{ marginBottom: "90px" }}>
          <img
            src={`/images/${user.bannerPicture}`}
            className="mt-2"
            style={{ height: "200px" }}
          />
          <img
            src={`/images/${user.profilePicture}`}
            className="position-absolute"
            style={{
              borderWidth: "5px",
              borderRadius: "50%",
              borderColor: "white",
              left: "20px",
              top: "200px",
              height: "150px",
              borderStyle: "solid",
            }}
          />
          <Link
            to="/editprofile"
            className="btn btn-outline-primary position-absolute"
            style={{ top: "270px", left: "500px" }}
          >
            Edit Profile
          </Link>
        </div>
        <h3 style={{ marginBottom: "5px" }}>{user.name}</h3>
        <div style={{ marginBottom: "2px" }}>{user.handle}</div>
        {user.bio} <br />
        <FontAwesomeIcon icon={faCalendar} className="me-1" /> Joined{" "}
        {user.dateJoined} <br />
        {user.followingCount} Following {user.followersCount} Followers <br />
        <>
          {user.location && (
            <>
              <FontAwesomeIcon icon={faLocationDot} /> {user.location}
            </>
          )}
          {!user.location && <>update your location</>}
        </>
      </div>
    </div>
  );
};
export default ProfileComponent;
