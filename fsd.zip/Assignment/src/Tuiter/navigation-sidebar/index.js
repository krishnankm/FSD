import React from "react";
import { Link } from "react-router-dom";
import { useLocation } from "react-router";

const NavigationSidebar = () => {
  const { pathname } = useLocation();
  const paths = pathname.split("/");
  const active = paths[1];

  return (
    <div className="list-group">
      <a className="list-group-item">Tuiter</a>
      <Link
        to="/home"
        className={`list-group-item ${active === "home" ? "active" : ""}`}
      >
        Home
      </Link>
      <Link
        to="/"
        className={`list-group-item ${active === "" ? "active" : ""}`}
      >
        Explore
      </Link>
      <Link to="/" className="list-group-item">
        Notifications
      </Link>
      <Link to="/" className="list-group-item">
        Messages
      </Link>
      <Link to="/" className="list-group-item">
        Labs
      </Link>
      <Link to="/" className="list-group-item">
        Bookmarks
      </Link>
      <Link to="/" className="list-group-item">
        Lists
      </Link>
      <Link
        to="/profile"
        className={`list-group-item ${
          active === "profile" || active === "editprofile" ? "active" : ""
        }`}
      >
        Profile
      </Link>
      <Link to="/" className="list-group-item">
        More
      </Link>
    </div>
  );
};
export default NavigationSidebar;
