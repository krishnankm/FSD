import { createSlice } from "@reduxjs/toolkit";
import hometuits from "../data/TuitStats.json";
const user = {
  account: "MisterIster",
  userName: "ister16",
  handle: "@mist",
  dp: "cap.jpeg",
  hasImage: false,
};
const templateTuit = {
  ...user,
  topic: "Sports",
  time: "2s",
  liked: false,
  replies: 0,
  retweet: 0,
  like: 0,
};
const hometuitsSlice = createSlice({
  name: "TuitStats",
  initialState: hometuits,
  reducers: {
    deleteTuit(state, action) {
      const index = state.findIndex((tuit) => tuit._id === action.payload);
      state.splice(index, 1);
    },
    createTuit(state, action) {
      state.unshift({
        ...action.payload,
        ...templateTuit,
        _id: new Date().getTime(),
      });
    },
    liker(state, action) {
      const index = state.find((tuit) => tuit._id === action.payload);
      if (index.liked) {
        index.like -= 1;
      } else {
        index.like += 1;
      }
      index.liked = !index.liked;
    },
  },
});

export const { createTuit, deleteTuit, liker } = hometuitsSlice.actions;
export default hometuitsSlice.reducer;
