import { useSelector } from "react-redux";
import profile from "../data/profile.json";
import { createSlice } from "@reduxjs/toolkit";
const profileSlice = createSlice({
  name: "profile",
  initialState: profile,
  reducers: {
    updateinfos(state, action) {
      state.name = action.payload[0] == "" ? state.name : action.payload[0];
      state.bio = action.payload[1] == "" ? state.bio : action.payload[1];
      state.location =
        action.payload[2] == "" ? state.location : action.payload[2];
    },
  },
});

export const { updateinfos } = profileSlice.actions;
export default profileSlice.reducer;
